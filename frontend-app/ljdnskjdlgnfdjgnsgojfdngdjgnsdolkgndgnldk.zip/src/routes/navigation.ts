import type { LucideIcon } from 'lucide-react';
import {
  Activity,
  AlertOctagon,
  Bell,
  Building2,
  BuildingIcon,
  ClipboardList,
  Gauge,
  LayoutDashboard,
  Megaphone,
  BarChart3,
  FileBarChart2,
  NotebookTabs,
  ShieldCheck,
  Search,
  ServerCog,
  SlidersHorizontal,
  KeyRound,
  PlugZap,
  RefreshCw,
  Stethoscope,
  Wrench,
  Settings,
  ShieldAlert,
  Siren,
  Scale,
  UserRoundSearch,
} from 'lucide-react';

export type NavigationItem = {
  label: string;
  to: string;
  permission?: string | string[];
  icon: LucideIcon;
  group:
    | 'Core'
    | 'Public'
    | 'Provider'
    | 'Taskforce'
    | 'Emergency'
    | 'Analytics'
    | 'Administration'
    | 'System';
};

export const navigationItems: NavigationItem[] = [
  { label: 'Dashboard', to: '/app', permission: 'dashboard.read', icon: LayoutDashboard, group: 'Core' },
  { label: 'Notifications', to: '/app/notifications', permission: 'notifications.view', icon: Bell, group: 'Core' },
  { label: 'Settings', to: '/app/settings', icon: Settings, group: 'Core' },

  { label: 'Public Timeline', to: '/app/public/timeline', icon: Activity, group: 'Public' },
  { label: 'Doctor Registry', to: '/app/public/doctor-registry', permission: 'doctor.registry.read', icon: UserRoundSearch, group: 'Public' },

  { label: 'Provider Hub', to: '/app/provider/dashboard', permission: 'provider.patient.read', icon: Building2, group: 'Provider' },
  { label: 'Patient Search', to: '/app/provider/patients', permission: 'provider.patient.read', icon: Search, group: 'Provider' },
  { label: 'Encounters', to: '/app/provider/encounters', permission: 'encounters.view', icon: ClipboardList, group: 'Provider' },
  { label: 'Labs', to: '/app/provider/labs', permission: 'labs.view', icon: NotebookTabs, group: 'Provider' },
  { label: 'Pharmacy', to: '/app/provider/pharmacy', permission: 'pharmacy.view', icon: BuildingIcon, group: 'Provider' },
  { label: 'Institution Ops', to: '/app/institution/dashboard', permission: 'institution.dashboard.view', icon: Building2, group: 'Provider' },

  { label: 'Taskforce', to: '/app/taskforce/dashboard', permission: 'cases.view', icon: ShieldAlert, group: 'Taskforce' },
  { label: 'Complaints', to: '/app/taskforce/complaints', permission: 'complaints.view', icon: AlertOctagon, group: 'Taskforce' },
  { label: 'Case Management', to: '/app/taskforce/cases', permission: 'cases.view', icon: ClipboardList, group: 'Taskforce' },
  { label: 'Governance Audit', to: '/app/governance/audit', permission: 'audit.view', icon: NotebookTabs, group: 'Taskforce' },
  { label: 'Oversight', to: '/app/governance/oversight', permission: 'oversight.view', icon: Scale, group: 'Taskforce' },

  { label: 'Emergency Inventory', to: '/app/emergency', permission: 'emergency.request.read', icon: Siren, group: 'Emergency' },
  { label: 'Emergency Cases', to: '/app/emergency/cases', permission: 'emergency.view', icon: AlertOctagon, group: 'Emergency' },
  { label: 'Alerts', to: '/app/alerts', permission: 'alerts.view', icon: Megaphone, group: 'Emergency' },

  { label: 'Analytics', to: '/app/analytics/dashboard', permission: ['analytics.view', 'analytics.read'], icon: Gauge, group: 'Analytics' },
  { label: 'Health Metrics', to: '/app/analytics/metrics', permission: ['analytics.view', 'analytics.read'], icon: BarChart3, group: 'Analytics' },
  { label: 'Reports', to: '/app/reports', permission: ['reports.generate', 'reports.read'], icon: FileBarChart2, group: 'Analytics' },
  { label: 'Data Quality', to: '/app/compliance/data-quality', permission: 'compliance.view', icon: ShieldCheck, group: 'Analytics' },
  { label: 'Compliance', to: '/app/compliance/dashboard', permission: 'compliance.view', icon: Scale, group: 'Analytics' },

  { label: 'Integrations', to: '/app/integrations', permission: 'integrations.manage', icon: PlugZap, group: 'Administration' },
  { label: 'API Keys', to: '/app/integrations/api-keys', permission: 'integrations.api_keys.manage', icon: KeyRound, group: 'Administration' },
  { label: 'Sync Monitor', to: '/app/integrations/sync', permission: 'integrations.sync.view', icon: RefreshCw, group: 'Administration' },

  { label: 'Admin Users', to: '/app/admin/users', permission: 'admin.users.manage', icon: BuildingIcon, group: 'Administration' },
  { label: 'Admin Roles', to: '/app/admin/roles', permission: 'admin.roles.manage', icon: ShieldAlert, group: 'Administration' },
  { label: 'Institutions', to: '/app/admin/institutions', permission: 'admin.settings.manage', icon: Building2, group: 'Administration' },
  { label: 'System Config', to: '/app/system/configuration', permission: 'admin.settings.manage', icon: SlidersHorizontal, group: 'Administration' },

  { label: 'System Health', to: '/app/system/health', permission: ['system.health.view', 'system.activity.view'], icon: Stethoscope, group: 'System' },
  { label: 'System Monitoring', to: '/app/system/monitoring', permission: ['system.monitoring.view', 'system.activity.view'], icon: ServerCog, group: 'System' },
  { label: 'System Activity', to: '/app/system/activity', permission: 'system.activity.view', icon: Activity, group: 'System' },
  { label: 'Observability', to: '/app/system/observability', permission: ['system.observability.view', 'system.activity.view'], icon: ServerCog, group: 'System' },
  { label: 'Dev Tools', to: '/app/dev-tools', permission: ['dev.tools.view', 'admin.settings.manage'], icon: Wrench, group: 'System' },
];
