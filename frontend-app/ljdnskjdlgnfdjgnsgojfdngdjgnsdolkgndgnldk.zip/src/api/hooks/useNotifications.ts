﻿import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { endpoints } from '@/api/endpoints';
import { apiClient } from '@/api/apiClient';
import { useNotificationsStore, type AppNotification } from '@/stores/notificationsStore';

export type NotificationItem = AppNotification & {
  sourceModule: string;
  priority: 'info' | 'warning' | 'critical';
  type: string;
};

export type NotificationsParams = {
  type?: string;
  unread?: boolean;
};

function normalizeNotification(item: Record<string, unknown>): NotificationItem {
  return {
    id: String(item.id ?? item.notificationId ?? crypto.randomUUID()),
    title: String(item.title ?? 'Notification'),
    message: String(item.description ?? item.message ?? ''),
    read: Boolean(item.read ?? item.isRead ?? false),
    createdAt: String(item.createdAt ?? new Date().toISOString()),
    sourceModule: String(item.sourceModule ?? item.module ?? 'system'),
    priority: String(item.priority ?? 'info').toLowerCase() as NotificationItem['priority'],
    type: String(item.type ?? item.eventType ?? 'general'),
  };
}

export function useNotifications(params: NotificationsParams = {}) {
  const storeItems = useNotificationsStore((state) => state.items);

  return useQuery({
    queryKey: ['system', 'notifications', params],
    queryFn: async (): Promise<NotificationItem[]> => {
      try {
        const response = await apiClient.get<Record<string, unknown>>(endpoints.notifications.list, {
          query: { type: params.type, unread: params.unread ? 'true' : undefined },
        });

        const items =
          (Array.isArray(response.items) ? response.items : null) ??
          (Array.isArray(response.data) ? response.data : null) ??
          [];

        return items
          .filter((item): item is Record<string, unknown> => Boolean(item && typeof item === 'object'))
          .map(normalizeNotification);
      } catch {
        return storeItems.map((item) => ({
          ...item,
          sourceModule: 'system',
          priority: 'info',
          type: 'general',
        }));
      }
    },
  });
}

export function useMarkNotificationRead() {
  const queryClient = useQueryClient();
  const markAllReadLocal = useNotificationsStore((state) => state.markAllRead);

  return useMutation({
    mutationFn: async (payload: { id?: string; all?: boolean }) => {
      if (payload.all) {
        try {
          await apiClient.post(endpoints.notifications.readAll, {});
        } catch {
          markAllReadLocal();
        }
        return;
      }

      if (!payload.id) return;

      try {
        await apiClient.patch(endpoints.notifications.read(payload.id), { read: true });
      } catch {
        // no-op fallback
      }
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['system', 'notifications'] });
    },
  });
}

