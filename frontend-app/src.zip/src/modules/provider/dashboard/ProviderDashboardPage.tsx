import { Link } from 'react-router-dom';
import { PageHeader } from '@/components/layout/PageHeader';
import { KpiGrid } from '@/components/data/KpiGrid';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { PermissionGate } from '@/components/navigation/PermissionGate';

export function ProviderDashboardPage() {
  return (
    <div className="space-y-6">
      <PageHeader
        title="Provider Dashboard"
        description="Operational overview for patient care, labs, pharmacy, and emergency attention."
        breadcrumbs={[{ label: 'Provider' }, { label: 'Dashboard' }]}
      />

      <KpiGrid />

      <Card>
        <CardHeader>
          <div>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Common workflow shortcuts for provider teams.</CardDescription>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button asChild variant="outline">
              <Link to="/app/provider/patients">Search patient</Link>
            </Button>
            <PermissionGate permission={['records.create', 'records.entry.create']}>
              <Button variant="outline">Add record</Button>
            </PermissionGate>
            <PermissionGate permission={['labs.create', 'lab.results.write']}>
              <Button variant="outline">Open lab entry</Button>
            </PermissionGate>
            <PermissionGate permission={['pharmacy.create', 'pharmacy.dispense.write']}>
              <Button variant="outline">Open pharmacy entry</Button>
            </PermissionGate>
          </div>
        </CardHeader>
      </Card>
    </div>
  );
}
