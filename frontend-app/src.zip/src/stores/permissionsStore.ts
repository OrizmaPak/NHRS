import { create } from 'zustand';

type PermissionsState = {
  permissions: Set<string>;
  replace: (permissions: string[]) => void;
  clear: () => void;
  hasPermission: (permission: string) => boolean;
  hasAny: (required: string[]) => boolean;
};

export const usePermissionsStore = create<PermissionsState>((set, get) => ({
  permissions: new Set<string>(),
  replace: (permissions) => set({ permissions: new Set(permissions) }),
  clear: () => set({ permissions: new Set<string>() }),
  hasPermission: (permission) => get().permissions.has(permission),
  hasAny: (required) => required.some((permission) => get().permissions.has(permission)),
}));
